package ex0417;

import java.util.ArrayList;

public class test {

	public static void main(String[] args) throws Exception {
		list();
		
	}
	
	public static void list() throws Exception {}
	
	public static void insert() throws Exception {}
	
	public static void update() throws Exception {}
	
	public static void delete() throws Exception {}
}
